from agent.intent import IntentAnalyzer
from knowledge.knowledge_base import KnowledgeBase

class EmbeddedChatAgent:
    def __init__(self):
        self.kb = KnowledgeBase()
        self.intent = IntentAnalyzer(self.kb)

    def start_chat(self):
        print("=" * 60)
        print("    嵌入式课程实验智能助手 Agent（多文件标准版）")
        print("  支持：实验介绍 | 代码生成 | 接线指导 | 故障排查")
        print("  输入 exit 退出")
        print("=" * 60)

        while True:
            msg = input("\n你：")
            if msg.lower() in ["exit", "quit", "退出"]:
                print("助手：实验顺利！再见～")
                break

            reply = self.intent.analyze(msg)
            print("\n助手：" + reply)