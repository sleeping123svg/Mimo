class IntentAnalyzer:
    def __init__(self, kb):
        self.kb = kb

    def analyze(self, question):
        q = question.lower()

        # 实验介绍
        if any(w in q for w in ["介绍", "是什么", "干嘛"]):
            if "流水灯" in q:
                return self.kb.exp_intro["流水灯"]
            if "数码管" in q:
                return self.kb.exp_intro["数码管"]
            if "按键" in q:
                return self.kb.exp_intro["按键控制"]

        # 代码模板
        if any(w in q for w in ["代码", "写代码", "程序", "模板"]):
            if "流水灯" in q:
                return self.kb.code_lib["流水灯标准代码"]
            if "数码管" in q:
                return self.kb.code_lib["数码管显示代码"]

        # 接线
        if any(w in q for w in ["接线", "怎么接", "连线"]):
            if "流水灯" in q:
                return self.kb.wiring["流水灯接线"]
            if "数码管" in q:
                return self.kb.wiring["数码管接线"]
            if "按键" in q:
                return self.kb.wiring["按键接线"]

        # 故障
        if any(w in q for w in ["不亮", "没反应", "故障", "坏了"]):
            if "数码管" in q:
                return self.kb.troubles["数码管不亮"]
            if "led" in q or "灯" in q:
                return self.kb.troubles["LED不亮"]
            if "按键" in q:
                return self.kb.troubles["按键没反应"]

        # 报错
        if "error" in q or "报错" in q:
            if "declared" in q:
                return self.kb.errors["not declared"]
            if "syntax" in q:
                return self.kb.errors["syntax error"]
            return "请告诉我具体报错内容~"

        return "我可以帮你：\n1. 实验介绍 2. 生成代码 3. 接线指导 4. 故障排查"