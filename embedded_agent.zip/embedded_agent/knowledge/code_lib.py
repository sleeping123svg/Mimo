class CodeLibrary:
    def get_codes(self):
        return {
            "流水灯标准代码": """
// IAP15F2K61S2 流水灯代码
#include <STC15F2K60S2.H>
typedef unsigned char u8;
typedef unsigned int u16;

void delay(u16 t) { while(t--); }

void main(void) {
    u8 led = 0xFE;
    while(1) {
        P2 = led;
        delay(50000);
        led = (led << 1) | 1;
        if(led == 0xFF) led = 0xFE;
    }
}
""",

            "数码管显示代码": """
// IAP15F2K61S2 数码管静态显示
#include <STC15F2K60S2.H>
typedef unsigned char u8;
u8 code seg_table[16] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

void main(void) {
    P0 = seg_table[5]; // 显示 5
    while(1);
}
"""
        }