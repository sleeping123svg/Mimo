from knowledge.code_lib import CodeLibrary
from knowledge.trouble import TroubleShooting

class KnowledgeBase:
    def __init__(self):
        # 实验介绍
        self.exp_intro = {
            "流水灯": "51单片机基础实验，通过IO口高低电平轮流点亮LED，核心：延时+移位。",
            "数码管": "段选+位选控制数字显示，IAP15F2K61S2常用共阴极数码管。",
            "按键控制": "检测电平变化，需消抖处理，避免机械抖动误触发。"
        }

        # 接线
        self.wiring = {
            "流水灯接线": "LED正极 → 220Ω电阻 → P2.0~P2.7；负极 → GND。",
            "数码管接线": "段选→P0，位选→P2.2~P2.3，公共端→GND。",
            "按键接线": "一端→P3.2，一端→GND，开启内部上拉。"
        }

        # 加载代码 & 故障库
        self.code_lib = CodeLibrary().get_codes()
        self.troubles = TroubleShooting().get_troubles()
        self.errors = TroubleShooting().get_errors()