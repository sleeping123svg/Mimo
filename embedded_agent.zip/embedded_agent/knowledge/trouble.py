class TroubleShooting:
    def get_troubles(self):
        return {
            "数码管不亮": "1.供电 2.接线 3.IO口输出 4.共阴/共阳匹配",
            "LED不亮": "1.电阻 2.接线正反 3.IO模式 4.电平输出",
            "按键没反应": "1.未消抖 2.上拉电阻 3.接线 4.逻辑错误"
        }

    def get_errors(self):
        return {
            "not declared": "变量未定义，检查typedef或拼写",
            "syntax error": "语法错误，检查分号、大括号配对"
        }