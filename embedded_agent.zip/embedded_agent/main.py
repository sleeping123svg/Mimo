from agent.chat_agent import EmbeddedChatAgent

if __name__ == '__main__':
    agent = EmbeddedChatAgent()
    agent.start_chat()