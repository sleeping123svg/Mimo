# 可扩展：文本格式化、日志、配置读取等
def format_print(text):
    return "\n" + text + "\n"